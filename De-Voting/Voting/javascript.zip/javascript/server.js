/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';
const Joi = require('joi');
const express = require('express');
const cors = require('cors');
const app = express();


app.use(express.json());
app.use(cors());


const { FileSystemWallet, Gateway, X509WalletMixin } = require('fabric-network');
const path = require('path');
const ccpPath = path.resolve(__dirname, '..', '..', 'first-network', 'connection-org1.json');
var userId = '';

const walletPath = path.join(process.cwd(), 'wallet');
const wallet = new FileSystemWallet(walletPath);
console.log(`Wallet path: ${walletPath}`);



async function main() {
    try {

        async function register() {
            try {        
                const gateway = new Gateway();
                await gateway.connect(ccpPath, { wallet, identity: 'admin', discovery: { enabled: true, asLocalhost: true } });
        
                const ca = gateway.getClient().getCertificateAuthority();
                const adminIdentity = gateway.getCurrentIdentity();
                
                const secret = await ca.register({ affiliation: 'org1.department1', enrollmentID: arguments[0], role: 'client' }, adminIdentity);
                const enrollment = await ca.enroll({ enrollmentID: arguments[0], enrollmentSecret: secret });
                const userIdentity = X509WalletMixin.createIdentity('Org1MSP', enrollment.certificate, enrollment.key.toBytes());
                await wallet.import(arguments[0], userIdentity);
                console.log(`Successfully registered and enrolled admin user ${arguments[0]} and imported it into the wallet`);
                return true;
            } catch (error) {
                console.error(`Failed to register user ${arguments[0]}: ${error}`);
                process.exit(1);
            }
        }

        async function authorize() {
            // Check to see if we've already enrolled the user.
            const userExists = await wallet.exists(userId);
            if (!userExists) {
                console.log('An identity for the user "user1" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
            // Create a new gateway for connecting to our peer node.
            const gateway = new Gateway();
            await gateway.connect(ccpPath, { wallet, identity: userId, discovery: { enabled: true, asLocalhost: true } });

            // Get the network (channel) our contract is deployed to.
            const network = await gateway.getNetwork('mychannel');

            // Get the contract from the network.
            const contract = network.getContract('fabcar');
            return contract;
        }

        async function signIn() {
            // Check to see if we've already enrolled the user.
            const userExists = await wallet.exists(arguments[0]);
            const gateway = new Gateway();
            await gateway.connect(ccpPath, { wallet, identity: arguments[0], discovery: { enabled: true, asLocalhost: true } });

            if (!userExists) {
                console.log('FROM SIGN IN An identity for the user user does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return false;
            } else {
                return true;
            }
        }

        async function getTransaction(){
            const result = await arguments[1].evaluateTransaction('queryCar',arguments[0]);
            const r = JSON.parse(result);
            return r;

        }

        async function getAllTransactions(){
            const result = await arguments[0].evaluateTransaction('queryAllCars');
            const r = JSON.parse(result);
            return r;
        }

        app.get('/',(req,res) => {
            res.send('This is root');
        });

        app.post('/reg',async function(req,res) {
            register(req.body.ident)
            res.json('success');
            
        });
        
        app.get('/viewTransaction',async function(req,res) {
            const cont = await authorize();
            const result1 = await getAllTransactions(cont); 
            res.json(result1);
        });

        app.get('/viewTransaction/:tid',async function(req,res) {
            const cont = await authorize();
            const tid = req.params.tid;
            const result1 = await getTransaction(tid,cont); 
            res.send(result1);
        });

        app.post('/signin',async function(req,res) {
            if(await signIn(req.body.email)) {
                userId = req.body.email;
                res.json('success')
            }else {
                res.status(400).json('error logging in!!!')
            }
        });

        app.post('/signout', async function(req, res) {
            if(req.body.isSignOut) {
                userId = '';
            }
        });
       
    } catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        process.exit(1);
    }
}

app.listen(3001, () => {
    console.log('server is running on port 3001')
})

main();
