import React from 'react';
import LogsList from '../LogsList/LogsList';
const ViewTransaction = ({isTransactionData,transactionData}) => {
    if(isTransactionData) {
        console.log("From View",transactionData)
      return(
        <div className='f1'>
            <LogsList transactionData={transactionData} />  
        </div>
    );  
    } else 
    {
        return (
            <div></div>
        )
    }
    
}

export default ViewTransaction;