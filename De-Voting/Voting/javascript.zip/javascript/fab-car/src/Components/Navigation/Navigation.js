import React from 'react';
import 'tachyons';

class Navigation extends React.Component {
    constructor() {
        super();
        this.state = {
            emailChange: null,
            password: null
        }
    }

    onSignOut = async () => {
        this.props.onRouteChange('signin');

    }

    render() {
        const {onRouteChange, isSignedIn} = this.props;
        if(isSignedIn) {
            return (
                <nav className='navi bg-black-90 w-100' style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <p className='f3 link dim white pa3 pointer' onClick={this.onSignOut} >Sign Out</p>
                    <p className='f3 link dim white pa3 pointer' onClick={() => onRouteChange('home')} >Home</p>
                </nav>
            );
        }else {
            return (
                <nav className='navi bg-black-90 w-100' style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <p className='f3 link dim white pa3 pointer' onClick={() => onRouteChange('signin')} >Sign in</p>
                    <p className='f3 link dim white pa3 pointer' onClick={() => onRouteChange('register')} >Register</p>
                </nav>
            );
        }
    }
}

export default Navigation;