import React from 'react';
import 'tachyons';

class GetTransaction extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
           data:null,
           tid: null
        }
    }

    onClickingView = async (id) => {
        await fetch(`http://localhost:3001/viewTransaction/${id}`)
      .then(response => response.json())
      .then(data => {
          this.setState({ data })
          this.props.onClickingView({data: this.state.data});
          this.props.onRouteChange('logs');
        });
      
        
    }

    onInputChange = (event) => {
        this.setState({ tid: event.target.value });
    }

    render() {
        return(
            <div>
                <div className='f3'>
                      <div className='f-subheadline  lh-title ttu fw5 pt5'>
                          {'Audit Logs'}  
                      </div> 
                      <div className='pa3'>{'This Website lets you audit the logs'} </div>        
              </div> 
                <div className='center'>
                    <div className='pa2'>
                        <button className='pa2' onClick={() => this.onClickingView('')} >View All Logs</button>
                    </div>
                    <div>
                        <input className='pa2' onChange={this.onInputChange} type='text' />
                        <input className='pa2' onClick={() => this.onClickingView(this.state.tid)} type='submit' />
                    </div>
                </div>
            </div>
        );
        
    }
}

export default GetTransaction;