import React from 'react';
import Logs from '../Logs/Logs';

class LogsList extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
           data:null,
        }
    }

    onClickingView = async (id) => {
        await fetch(`http://localhost:3001/viewTransaction/${id}`)
      .then(response => response.json())
      .then(data => {
          this.setState({ data })
          this.props.onClickingView({data: this.state.data});
          this.props.onRouteChange('logs');
        });
    }
    renderTableData(dataLogs) {
        return dataLogs.map((dataLog, index) => {
            return (
                <div class="pa4">
                    <div class="overflow-auto">
                        <table class="f6 w-100 mw8 center" cellspacing="0">
                     <tbody class="lh-copy">
                    <tr class="stripe-dark">
                    <td class="pa1">{dataLog.Key}</td>
                    <td class="pa1">{dataLog.Record.load}</td>
                    <td class="pa1">{dataLog.Record.memory}</td>
                    <td class="pa1">{dataLog.Record.os}</td>
                    <td class="pa1">{dataLog.Record.ram}</td>
                    </tr>
                </tbody>
                </table>
                </div>
                </div>
            )
        })
  }

    render() {
        const dataLogs = this.props.transactionData.data;
        return(
            <div class="pa4">
  <div class="overflow-auto">
    <table class="f6 w-100 mw8 center" cellspacing="0">
      <thead>
        <tr class="stripe-dark">
          <th class="fw6 tl pa3 bg-white">TID</th>
          <th class="fw6 tl pa3 bg-white">Load</th>
          <th class="fw6 tl pa3 bg-white">Memory</th>
          <th class="fw6 tl pa3 bg-white">OS</th>
          <th class="fw6 tl pa3 bg-white">Ram</th>
        </tr>
      </thead>
      <tr>
      {this.renderTableData(dataLogs)}
      </tr>
    </table>
  </div>
</div>
            );
    }
};

export default LogsList;