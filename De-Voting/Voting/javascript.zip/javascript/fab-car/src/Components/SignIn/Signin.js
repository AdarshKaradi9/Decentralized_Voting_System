import React from 'react';

class Signin extends React.Component {
    constructor() {
        super();
        this.state = {
            id: null,
            idKey: null
        }
    }

    onIdChange = (event) => {
        this.setState({ id: event.target.value })
    }
    // onIdKeyChange = (event) => {
    //     this.setState({ idKey: event.target.value })
    // }

    onSubmitSignIn =  () => {
         fetch(`http://localhost:3001/signin`, {
            method: 'post',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
            email: this.state.id,
                // password: this.state.idKey
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data === 'success') {
                this.props.onRouteChange('home');
            }else {
                alert('user does not exists!!')
                this.props.onRouteChange('signin');
            }
        })
        
    }


    render() {
        return(
            <div>
            <article className="br3 ba dark-gray b--black-10 mv4 w-100 w-50-m w-25-l mw6 shadow-5 center">
                <main className="pa4 black-80">
                    <div className="measure">
                        <fieldset id="sign_up" className="ba b--transparent ph0 mh0">
                            <legend className="f1 center fw6 ph0">Sign In</legend>
                            <div>
                                <label className="fw6 lh-copy f6" htmlFor="email-address">Identity</label>
                                <input className="pa2 input-reset ba bg-transparent w-100" onChange={this.onIdChange} type="email" name="email" id="email" />
                            </div>
                            <div className="mt3">
                                <label className="fw6 lh-copy f6" htmlFor="email-address">Identity Key</label>
                                <input className="pa2 input-reset ba bg-transparent w-100" onChange={this.onIdChange} type="email" name="email" id="email" />
                            </div>
                        </fieldset>
                        <div className="">
                            <input className="b ph3 pv2 input-reset ba b--black bg-transparent grow pointer f6 dib" type="submit" onClick={this.onSubmitSignIn} value="Sign in" />
                        </div>
                    </div>
                </main>
            </article>
        </div>
        );
    }
}

export default Signin;