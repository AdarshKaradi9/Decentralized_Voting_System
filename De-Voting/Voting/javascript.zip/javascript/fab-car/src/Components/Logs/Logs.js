import React from 'react';

const Logs = ({Key, load, memory, os, ram}) => {
    return(
        <div class="container">
                    <tr>
                    <th scope="row" style={{width:'100px'}}>{Key}</th>
                    <td style={{width:'100px'}}>{load}</td>
                    <td style={{width:'100px'}}>{memory}</td>
                    <td style={{width:'100px'}}>{os}</td>
                    <td style={{width:'100px'}}>{ram}</td>
                    </tr>
        </div>
    );
};

export default Logs;